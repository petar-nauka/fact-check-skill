# Fact Check Skill for Codex

Codex-only package. This repository is intended for OpenAI Codex and is not packaged for Claude.ai.

GitHub-ready package for the `fact-check` Codex skill.

The installable skill lives in [`fact-check/`](./fact-check).

## What it does

`fact-check` helps Codex:

- verify claims and news-like content
- compare two sources on the same topic
- assess source credibility and manipulation signals
- produce concise verdicts with confidence and supporting sources
- prepare prebunking briefings about active false narratives

## Codex only

This repository is designed only for Codex-style local skills.

- It is not a Claude.ai upload package.
- It is not a Claude Code `.claude/skills` package.
- The installable skill is the `fact-check/` folder, which should be placed in a Codex skills directory.

## Repository layout

```text
fact-check-skill-main/
|-- README.md
|-- LICENSE
|-- .gitignore
`-- fact-check/
    |-- SKILL.md
    |-- agents/openai.yaml
    `-- references/
```

## Install in Codex

### Option 1: Manual install

Copy the `fact-check/` folder into your Codex skills directory:

- Windows: `%USERPROFILE%\\.codex\\skills\\fact-check`
- macOS/Linux: `~/.codex/skills/fact-check`

The target folder must contain `SKILL.md` directly inside it.

### Option 2: Install from GitHub with Codex skill-installer

After uploading this repository to GitHub, install the skill from the repo path that contains the actual skill folder:

```powershell
python "%USERPROFILE%\\.codex\\skills\\.system\\skill-installer\\scripts\\install-skill-from-github.py" --repo YOUR_GITHUB_USER/YOUR_REPO --path fact-check
```

Adjust the command for your platform if needed.

## After install

Restart Codex so it can discover the new skill.

## Usage examples

- `Fact check this claim: ...`
- `Is this true?`
- `Compare these two sources and tell me which is more reliable.`
- `What false narratives are currently circulating about elections in Bulgaria?`
- `Use $fact-check to verify this screenshot.`

## Notes

- The repository root is for GitHub and humans.
- The `fact-check/` subfolder is the actual Codex-installable skill.
- If you want a Claude.ai version, package that separately from this repository.
