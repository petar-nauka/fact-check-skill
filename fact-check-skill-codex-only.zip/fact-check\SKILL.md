---
name: fact-check
description: Verify factual claims, articles, screenshots, URLs, social posts, and competing sources. Use when a user asks whether something is true, fake, misleading, manipulated, or credible; asks to compare two sources; asks for a prebunking briefing on active false narratives; or wants a structured fact-check with verdict, confidence, sources, and red flags. Best for current or high-risk claims that require browsing, source triangulation, exact dates, and clear separation between evidence and inference.
---

# Fact Check

Use this skill to run a careful, transparent fact-check in Codex.

## Core Rules

- Use the current environment's available web tools for anything recent, unstable, high-risk, or source-sensitive.
- Prefer primary sources first: official statements, original datasets, research papers, court filings, platform records, and direct documentation.
- Treat fact-checking as evidence synthesis, not debate performance.
- Separate confirmed facts, strong inference, weak inference, and unresolved points.
- Use exact dates instead of relative time words when that improves clarity.
- Quote sparingly; summarize in your own words and link the sources you used.
- If browsing is unavailable or blocked, say so clearly and lower confidence.

## Choose the Mode

### Standard fact-check

Use for a claim, article, screenshot, video transcript, or URL that needs verification.

### Comparison

Use when the user provides two sources and asks which is more reliable, where they agree, or where they conflict.

### Prebunking briefing

Use when the user asks what false or misleading narratives are circulating about a topic.

### Quick check

Use for a narrow yes/no claim when a short answer is enough. Upgrade to a full fact-check if the claim breaks into multiple subclaims or needs significant context.

## Inputs

Handle:

- pasted text
- URLs
- screenshots or images with visible text
- two-source comparisons
- topic-only narrative scans

If the input contains multiple distinct claims, decompose them first. Ask one clarifying question only if the scope is genuinely ambiguous and choosing wrong would materially change the result.

## Workflow

1. Extract the claim or claims.
2. Classify each item:
   - factual and checkable
   - opinion or value judgment
   - prediction or future claim
   - vague or unfalsifiable
   - implied claim that should be made explicit
3. Search laterally before trusting the original source.
4. Gather corroboration and contradiction from independent sources.
5. Trace the origin when the claim appears copied, reposted, or clipped out of context.
6. Look for manipulation signals such as emotional pressure, fake authority, context stripping, cherry-picking, false causality, and recycled old material.
7. Assign a verdict for each checkable claim.
8. Calibrate confidence based on source quality, agreement, directness, and recency.
9. Give the user a concise literacy takeaway so they can recognize the pattern next time.

## Source Evaluation

Score sources mentally using these checks:

- Currency: Is it current enough for the claim?
- Relevance: Does it directly address the claim?
- Authority: Is it original, expert, or merely repeating others?
- Accuracy: Does it provide evidence, methods, or traceable records?
- Purpose: Is it informing, persuading, selling, recruiting, or rage-baiting?

Do not give weak sources equal weight just for "balance." Weight them by evidence quality.

## Verdict Labels

Use one of these when possible:

- Confirmed
- Mostly true
- Mixed
- Misleading
- False
- Unverifiable
- Opinion / not fact-checkable
- Prediction / not yet verifiable

For multi-claim inputs, give both:

- a per-claim verdict
- a top-line verdict summarizing the overall reliability of the content

## Output Contract

For a quick check, return:

- verdict
- confidence
- 1-2 sentence explanation
- 2-4 key sources
- one short "how to verify this yourself" tip

For a full fact-check, return:

- Claim
- Verdict
- Confidence
- What the evidence shows
- Claim-by-claim breakdown when needed
- Best sources used
- Red flags or manipulation signals
- What remains uncertain
- Practical literacy tip
- Share-safe summary in 1-2 sentences

If the user explicitly asks for HTML or a card, provide a structured HTML artifact only after the analysis is complete. Keep the analysis accurate first and decorative second.

## Comparison Mode

When comparing two sources:

- identify the core claim each source makes
- note where they overlap
- isolate contradictions
- compare sourcing quality, not just writing style
- say which source is more reliable and why
- call out when both are flawed for different reasons

## Prebunking Mode

When the user asks about active false narratives:

- browse for current examples and exact dates
- group narratives by theme
- explain the manipulation pattern behind each one
- distinguish fringe claims from high-reach narratives if evidence allows
- end with a short inoculation section: what to watch for before sharing

## Images and Screenshots

When the input is an image:

- extract the visible text first
- note platform cues, timestamps, usernames, and engagement counts if present
- flag signs of cropping, misleading captions, or edited overlays
- if the image itself is central to the claim, suggest reverse image verification when appropriate

## Use Bundled References

- Read [references/fact-check-playbook.md](references/fact-check-playbook.md) when you need the detailed playbook for claim decomposition, verdict criteria, confidence calibration, comparison mode, or prebunking mode.
- Read [references/educational-tips.md](references/educational-tips.md) when you need manipulation-pattern examples, literacy tips, or Bulgaria-specific fact-checking resources.

Load only the parts you need.

## Failure Modes

- If credible sources disagree, say the evidence is mixed instead of forcing certainty.
- If the claim depends on missing data, say exactly what would resolve it.
- If a source is blocked, use alternatives, cached reporting, or primary-source mirrors where possible, and say what you could not verify directly.
- If the user asks for a conclusion beyond the evidence, say what is known and what is not.

## Style

- Be calm, concrete, and non-theatrical.
- Prefer short paragraphs and compact bullets over long essays.
- Avoid moralizing.
- Optimize for epistemic clarity and user trust.
