# Fact-Check Playbook

Use this file when the main skill needs more detailed operating guidance.

## 1. Claim Decomposition

Break the input into units that can be checked independently.

Use these labels:

- `F`: factual claim
- `I`: implied factual claim
- `S`: statistical claim
- `O`: opinion or value judgment
- `P`: prediction or future claim
- `U`: vague or unfalsifiable

Promote implied claims into explicit wording before checking them.

Examples:

- "Doctors are hiding the cure" -> factual subclaims about existence, knowledge, and concealment.
- "The EU banned home gardens" -> legal claim, jurisdiction claim, enforcement claim, and penalty claim.

## 2. Search Strategy

Start broad, then tighten.

Suggested sequence:

1. Search the exact claim in quotes if the wording is distinctive.
2. Search the core nouns without the rhetorical framing.
3. Search for the alleged source, institution, dataset, law, or speaker.
4. Search for fact-checks only after trying to locate the primary evidence.
5. Search in relevant languages if the claim originated outside English.

Prefer independent confirmation over repeated aggregation.

## 3. Lateral Reading

Before trusting a site or post, check what others say about it.

Look for:

- ownership and affiliation
- editorial standards
- prior corrections or sanctions
- whether the article cites traceable evidence
- whether quoted experts are real and relevant

## 4. Origin Tracing

When a claim appears recycled or copied:

- find the earliest accessible version
- identify whether later posts changed wording or certainty
- note if old footage, old images, or old reporting is being repackaged as new
- distinguish original reporting from repost chains

## 5. Manipulation Signals

Common signals:

- urgency or panic language
- "share before they delete this"
- unsupported insider claims
- fake precision without source access
- screenshots without links
- numbers without baseline or methodology
- headlines that overstate what the evidence supports
- real facts attached to false causal conclusions

Use the educational tips reference for examples and user-facing explanations.

## 6. Verdict Criteria

Use these heuristics:

- `Confirmed`: the core claim is directly supported by strong primary evidence.
- `Mostly true`: the main point is supported, but wording or context overreaches.
- `Mixed`: the content combines true and false or unsupported elements.
- `Misleading`: the facts presented omit key context, distort scale, or imply something unsupported.
- `False`: the claim is contradicted by strong evidence.
- `Unverifiable`: evidence is missing, inaccessible, or too weak.

For composite claims, avoid flattening everything into one verdict too early.

## 7. Confidence Calibration

Raise confidence when:

- there are multiple independent high-quality sources
- primary documentation is available
- dates, numbers, and quotations line up across sources
- the claim is specific and directly testable

Lower confidence when:

- all sources are derivative
- the key source is unavailable
- evidence is anecdotal or selectively clipped
- the claim relies on secret knowledge or broad motives
- the event is still unfolding

Use plain labels such as `High`, `Moderate`, or `Low`.

## 8. Comparison Mode

For two-source comparisons:

1. State each source's main thesis.
2. Compare evidence type: direct documents, firsthand reporting, expert synthesis, or commentary.
3. Compare timeliness and update history.
4. Compare whether each source addresses the strongest counterevidence.
5. Conclude with:
   - which source is more reliable
   - what each gets right
   - what each leaves out

## 9. Prebunking Mode

A prebunking briefing should contain:

- current narrative themes
- representative examples with dates
- the manipulation pattern behind each narrative
- the factual anchor the user can remember
- one short rule for spotting the pattern early

Do not overstate prevalence unless you have evidence of scale.

## 10. Response Patterns

### Quick check

Use this shape:

- Verdict: `False`
- Confidence: `High`
- Why: One or two sentences.
- Sources: 2-4 links with short labels.
- Tip: One sentence on how to verify similar claims.

### Full fact-check

Use this shape:

- Claim
- Verdict
- Confidence
- What the evidence shows
- Claim breakdown
- Sources
- Red flags
- Remaining uncertainty
- Share-safe summary

## 11. Bulgaria-Specific Notes

When the topic is relevant to Bulgaria:

- prefer Bulgarian primary or institutional sources when available
- verify whether a claim is about Bulgaria specifically, the EU generally, or another member state
- watch for mistranslations of EU proposals, directives, and enforcement scope
- distinguish draft proposals, adopted acts, and national implementation

Useful source types include:

- Bulgarian ministries and agencies
- National Statistical Institute
- Bulgarian parliament and legal gazette
- European Commission and EUR-Lex
- established Bulgarian fact-checking outlets
